<?php
function var_dump_pre ($value) {
	print "<pre>";
	var_dump ($value);
	print "</pre>";
}
