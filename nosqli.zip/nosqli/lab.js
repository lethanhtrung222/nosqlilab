function show_notes() {
	document.getElementById("notes").style="display:block"
	document.getElementById("show").style="display:none"
}
